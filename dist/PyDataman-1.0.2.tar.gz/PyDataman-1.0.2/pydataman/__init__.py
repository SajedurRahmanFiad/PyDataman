from .pydataman import CloudFile
from .pydataman import CloudVariable
from .pydataman import save
from .pydataman import read
from .pydataman import read_str
from .pydataman import exists
from .pydataman import get_all_as_dict
from .pydataman import is_android

