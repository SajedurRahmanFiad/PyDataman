from .pyvariable import LocalVariable
from .pyvariable import CloudVariable
